from src.char.BaseChar import SwitchPriority
from src.char.Suoming import Suoming as NativeSuoming


class Suoming(NativeSuoming):
    """心鎖卜(心/鎖暝/卜靈)裡的鎖暝。非本隊時整套走原版。

    宏體在同目錄的 Hsin.py, 這裡只轉發。宏在鎖暝變奏入場、HUD 回來時返回, 框架下一次調的就是她,
    所以她的 do_perform 必須轉給心的 drive()。
    自定義角色文件互相 import 不到, 用 task.chars 裡的實例按能力找。
    """

    @property
    def is_in_xss(self) -> bool:
        members = 0
        for char in self.task.chars:
            if char and char.name in {'Hsin', 'Douling'}:
                members += 1
        return members == 2

    def macro(self):
        """持宏的心。心那份自定義沒啟用時返回 None, 走原版。"""
        for char in self.task.chars:
            if char is None or char is self:
                continue
            if hasattr(char, 'drive') and hasattr(char, 'quick_switch'):
                return char
        return None

    def reset_state(self):
        super().reset_state()
        self.check_f_on_switch = False

    def do_perform(self):
        if not self.is_in_xss:
            return super().do_perform()
        macro = self.macro()
        if macro is None:
            self.logger.warning('xsd: Hsin custom code is off, falling back to the native rotation')
            return super().do_perform()
        macro.drive(self)

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """啟動軸待跑時返回 NO(要先上卜靈)。"""
        if self.is_in_xss:
            macro = self.macro()
            if macro is not None and macro.opener_pending():
                return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)