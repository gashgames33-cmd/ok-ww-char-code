from src.char.BaseChar import SwitchPriority
from src.char.Douling import Douling as NativeDouling


class Douling(NativeDouling):
    """心鎖卜(心/鎖暝/卜靈)裡的卜靈。非本隊時整套走原版(兩段式)。

    宏體在同目錄的 Hsin.py。卜靈是啟動軸的第一棒; 宏散掉時框架也可能先呼叫到她,
    所以她的 do_perform 一樣轉給心的 drive(), 不讓原版自己打一段再 switch_next_char。
    卦象讀取 gua()、空中判定 flying() 繼承自原版, 宏裡直接呼叫。
    """

    @property
    def is_in_xss(self) -> bool:
        members = 0
        for char in self.task.chars:
            if char and char.name in {'Hsin', 'Suoming'}:
                members += 1
        return members == 2

    def macro(self):
        """持宏的心。心那份自定義沒啟用時返回 None, 走原版。"""
        for char in self.task.chars:
            if char is None or char is self:
                continue
            if hasattr(char, 'drive') and hasattr(char, 'quick_switch'):
                return char
        return None

    def reset_state(self):
        super().reset_state()
        self.check_f_on_switch = False

    def do_perform(self):
        if not self.is_in_xss:
            return super().do_perform()
        macro = self.macro()
        if macro is None:
            self.logger.warning('xsd: Hsin custom code is off, falling back to the native rotation')
            return super().do_perform()
        macro.drive(self)

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """啟動軸待跑時卜靈必須先上(心/鎖暝此時都是 NO)。"""
        if self.is_in_xss:
            macro = self.macro()
            if macro is not None and macro.opener_pending():
                return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)